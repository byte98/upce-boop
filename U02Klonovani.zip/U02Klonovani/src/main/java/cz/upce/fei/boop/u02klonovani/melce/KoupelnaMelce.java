package cz.upce.fei.boop.u02klonovani.melce;

import cz.upce.fei.boop.u02klonovani.MojeException;
import cz.upce.fei.boop.u02klonovani.Rozmer;
import cz.upce.fei.boop.u02klonovani.Vana;
import java.util.Objects;

/**
 * TODO Upravte třídu KoupelnaMelce tak vyhověla testu a byla mělce klonovatelná
 * TODO Při upravách třídy dodržujte strukturu třídy podle editor-fold
 */
public class KoupelnaMelce {

//<editor-fold defaultstate="collapsed" desc="instanční proměnný/atributy">



//</editor-fold>
    
//<editor-fold defaultstate="collapsed" desc="konstruktory">
    

    


//</editor-fold>    


//<editor-fold defaultstate="collapsed" desc="klonování">
    
//</editor-fold>
    


//<editor-fold defaultstate="collapsed" desc="metoda toString">


//</editor-fold>    
    
//<editor-fold defaultstate="collapsed" desc="Metody get/set ">

//</editor-fold>
}
