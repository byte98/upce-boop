package cz.upce.fei.boop.u02klonovani.hluboce;

import cz.upce.fei.boop.u02klonovani.MojeException;
import cz.upce.fei.boop.u02klonovani.Rozmer;
import cz.upce.fei.boop.u02klonovani.Vana;
import java.util.Objects;

/**
 * TODO Upravte třídu KoupelnaHlubuce tak vyhověla testu a byla hluboce klonovatelná
 * TODO Při upravách třídy dodržujte strukturu třídy podle editor-fold
 */
public class KoupelnaHluboce  {

//<editor-fold defaultstate="collapsed" desc="instanční proměnný/atributy">
    

    
//</editor-fold>


//<editor-fold defaultstate="collapsed" desc="konstruktory">
    
//</editor-fold>


//<editor-fold defaultstate="collapsed" desc="metoda klonovani">
    
//</editor-fold>
    

//<editor-fold defaultstate="collapsed" desc="¨metoda toString">
    
//</editor-fold>

 
//<editor-fold defaultstate="collapsed" desc="metody get">
    
//</editor-fold>

}
