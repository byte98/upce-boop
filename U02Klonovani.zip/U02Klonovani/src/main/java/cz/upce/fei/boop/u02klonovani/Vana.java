package cz.upce.fei.boop.u02klonovani;

/*
 * TODO Upravte třídu Vana tak vyhověla testu a byla klonovatelná
 * TODO Při upravách třídy dodržujte strukturu třídy podle editor-fold
 */
public class Vana  {

//<editor-fold defaultstate="collapsed" desc="Instanční proměnný/atributy">

//</editor-fold>

//<editor-fold defaultstate="collapsed" desc="Konstruktory">

    
//</editor-fold>


//<editor-fold defaultstate="collapsed" desc="toString">

    
//</editor-fold>


//<editor-fold defaultstate="collapsed" desc="Metody get">

//</editor-fold>    

//<editor-fold defaultstate="collapsed" desc="Metody equals a hashCode ">
    
//</editor-fold>
}
