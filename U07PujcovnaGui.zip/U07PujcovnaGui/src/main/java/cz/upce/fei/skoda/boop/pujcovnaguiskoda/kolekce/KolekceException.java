package cz.upce.fei.skoda.boop.pujcovnaguiskoda.kolekce;

/**

 * @author karel@simerda.cz
 */
public class KolekceException extends Exception {

    public KolekceException() {
    }

}
