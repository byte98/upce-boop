package seznam.prostredky;

import java.util.Locale;
import java.util.Objects;

/**
 * TODO Doplnit alespoň jednoho dalšího potomka podle vlastního výběru.
 *
 * @author karel@simerda.cz
 */
public abstract sealed class Prostredek implements Cloneable
        permits OsobniAutomobil, NakladniAutomobil, Traktor {

  

   
  

   

}
