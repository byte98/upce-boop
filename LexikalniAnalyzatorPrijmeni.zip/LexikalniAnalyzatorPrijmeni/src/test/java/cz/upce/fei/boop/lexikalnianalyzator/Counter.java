package cz.upce.fei.boop.lexikalnianalyzator;

/**
 *
 * @author karel@simerda.cz
 */
public class Counter {
    // TODO Třída se natahuje při spuštění každého testu! Proč? 
   public static  int counter;
   static {
      counter = 1; 
   }
}
