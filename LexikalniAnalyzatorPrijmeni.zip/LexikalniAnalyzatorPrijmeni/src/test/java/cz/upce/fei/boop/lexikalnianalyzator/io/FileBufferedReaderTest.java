package cz.upce.fei.boop.lexikalnianalyzator.io;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author kasi0004
 */
public class FileBufferedReaderTest {
    
    public FileBufferedReaderTest() {
    }

    @Test
    public void testCreate() {
    }

    @Test
    public void testIsEOF() {
    }

    @Test
    public void testRead() throws Exception {
    }

    @Test
    public void testReadLine() throws Exception {
    }

    @Test
    public void testStream() {
    }
    
}
